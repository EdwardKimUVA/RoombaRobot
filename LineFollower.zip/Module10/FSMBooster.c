#include "FSM.h"
#include "Clock.h"
#include "gpio.h"
#include "Reflectance.h"
#include "PWM.h"
#include "Motor.h"
#include "Nokia5110.h"
#include "PortPins.h"
#include "Switch.h"
#define CYCLING_DELAY_MS     100
#define HEARTBEAT_DELAY_MS   100
#define DEBOUNCING_DELAY_MS  100
bool picked = false;
//--------------------------------------------------------------------------
// Initialize FSM
//--------------------------------------------------------------------------
void InitializeFSM2(FSMBooster *FSM)
{
    FSM->CurrentState = Normal_Operation;
    //bool picked = false;
    GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN0);
    GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN1);
    GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN2);
}

//--------------------------------------------------------------------------
// Determine next FSM state
//--------------------------------------------------------------------------
FSMBoostState NextStateFunction2(FSMBooster *FSM)
{
    FSMBoostState NextState = FSM->CurrentState;

    //int position = Reflectance_Position(FSM->linedata); // if (pos > 200
    if(FSM->acceldata !=0){
    	picked = true;
    }else{
    	picked = false;
    }
    switch (FSM->CurrentState){
//--Heart Beating states----------------------------------------------------
    case Normal_Operation:
    	if(FSM->luxdata == 2 && !picked){
    		NextState = Normal_Operation;
    	}else if(FSM->luxdata ==1 && !picked) {
    		NextState = Take_It_Slow;
    	}else if(FSM-> luxdata ==0 || picked){
    		NextState = Stop;
    	}
    case Take_It_Slow:
    	if(FSM->luxdata == 2 && !picked){
    		NextState = Normal_Operation;
    	}else if(FSM->luxdata ==1 && !picked) {
    		NextState = Take_It_Slow;
    	}else if(FSM-> luxdata ==0 || picked){
    		NextState = Stop;
    	}
    case Stop:
    	if(FSM->luxdata == 2 && !picked){
    		NextState = Normal_Operation;
    	}else if(FSM->luxdata ==1 && !picked) {
    		NextState = Take_It_Slow;
    	}else if(FSM-> luxdata ==0 || picked){
    		NextState = Stop;
    	}
    }
    return NextState;
}
//--------------------------------------------------------------------------
// Determine LED output based on state
//--------------------------------------------------------------------------
uint16_t OutputFunction2(FSMBooster *FSM)
{
    switch (FSM->CurrentState) {
    case Normal_Operation:
    	GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN0); //turns LEDs on
    	GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN1);
    	GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN2);
        return 40;
    case Take_It_Slow:
    	GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN0); //if the LEDs are on then it will turn them off
    	GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN1);
    	GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN2);
    	return 32;
    case Stop:
    	GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN0); //if the LEDs are on then it will turn them off
    	GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN1);
    	GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN2);
    	return 0;
    }
    return 5;
}
