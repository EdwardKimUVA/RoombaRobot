/* Driver Library Includes */
#include "gpio.h"
#include "timer_a.h"
#include "timerA1.h"
#include "interrupt.h"
/* Standard Includes */
#include <stdint.h>
#include "msp.h"
/* Project Includes */
#include "Clock.h"
#include "LaunchPad.h"
#include "Reflectance.h"
#include "FSM.h"
#include "Bump.h"
#include "PWM.h"
#include "Motor.h"
#include "UART0.h"
#include "Nokia5110.h"
#include "Booster_Pack/opt3001.h"
#include "Booster_Pack/i2c_driver.h"
#include "Booster_Pack/bmi160_support.h"
#include "Booster_Pack/bme280_support.h"
#include <math.h>
#include "CortexM.h"
/* Defines */
/*volatile uint32_t mclkFreq, smclkFreq;

Timer_A_UpModeConfig config =
{
 TIMER_A_CLOCKSOURCE_SMCLK,
 TIMER_A_CLOCKSOURCE_DIVIDER_64,
 1,
 TIMER_A_TAIE_INTERRUPT_DISABLE,
 TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE,
 TIMER_A_DO_CLEAR
};*/
volatile uint8_t data;
volatile uint8_t linedata=0x18;
volatile uint8_t bumpdata=0;
int8_t accel_off_x;
int8_t accel_off_y;
int8_t accel_off_z;
s16 gyro_off_x;
s16 gyro_off_y;
s16 gyro_off_z;
uint8_t accelGood;
//struct bmi160_accel_t       s_accelXYZ;
BMI160_RETURN_FUNCTION_TYPE returnValue;
//struct bmi160_gyro_t        s_gyroXYZ;
struct bmi160_accel_t       s_accelXYZ;
//struct bmi160_mag_xyz_s32_t s_magcompXYZ;
int returnRslt;
//FSMType TakeFiveFSM;
//uint32_t data4;
volatile int x = 0;
void Task(void){
    //LaunchPad_Init();
    //int x = 0;
    if(x == 0){
        Reflectance_Start();
    }
    if(x == 1){
        linedata = Reflectance_End();
    }
    if(x == 2){
        bumpdata = Bump_Read();
    }
    if (x==10){
        x=-1;
    }
    x++;
}
//Line follower main
int main(void){
    FSMLine TakeFiveFSM;
    FSMBooster BoostFSM;
    bumpdata=0;
    Clock_Init();
    //intialize i2c to communicate with booster pack
    initI2C();

    //Intialize opt3001 sensor
    sensorOpt3001Init();

    //initialize gyro/accelerometer
    bmi160_initialize_sensor();
    returnRslt = bmi160_config_running_mode(APPLICATION_NAVIGATION); //there are several modes to run the BMI sensor in
    bmi160_accel_foc_trigger_xyz(0x03, 0x03, 0x01, &accel_off_x, &accel_off_y, &accel_off_z);
    bmi160_set_foc_gyro_enable(0x01, &gyro_off_x, &gyro_off_y, &gyro_off_z);
    //other inits
    Reflectance_Init();
    Nokia5110_Init();
    TimerA1_Init(&Task,500); //1000 hz
    Bump_Init();
    Motor_Init();
    InitializeFSM(&TakeFiveFSM);
    InitializeFSM2(&BoostFSM);
    //bumper/blinker light set up
    GPIO_setAsOutputPin(GPIO_PORT_P8, GPIO_PIN0); //Front Left
    GPIO_setAsOutputPin(GPIO_PORT_P8, GPIO_PIN5); //Front Right
    GPIO_setAsOutputPin(GPIO_PORT_P8, GPIO_PIN6);// back left
    GPIO_setAsOutputPin(GPIO_PORT_P8, GPIO_PIN7);//back right
    //light booster init stuff
    uint16_t rawData;
    float convertedLux;
    uint8_t luxGood;
    uint16_t speed;
	int LUX_HIGH_LIMIT = 100;
	int X_LIMIT = 4000;
    while(1){
    	//Task();
        //Read and convert OPT values
        sensorOpt3001Read(&rawData);
        sensorOpt3001Convert(rawData, &convertedLux);
        if(convertedLux > LUX_HIGH_LIMIT){ //read the light value
            //stop the motors
            luxGood = 2;
        } else if (convertedLux < LUX_HIGH_LIMIT && convertedLux > 40){
            luxGood = 1;
        } else{
        	luxGood = 0;
        }
        bmi160_read_accel_xyz(&s_accelXYZ); //read the acceleration value
        if(s_accelXYZ.x > X_LIMIT | s_accelXYZ.y > X_LIMIT | s_accelXYZ.y < -1*X_LIMIT | s_accelXYZ.x < X_LIMIT*-1){
            accelGood = 1;
        } else{
            accelGood = 0;
        }
    	BoostFSM.acceldata = accelGood;
    	BoostFSM.luxdata = luxGood;
    	BoostFSM.CurrentState = NextStateFunction2(&BoostFSM);
    	speed = OutputFunction2(&BoostFSM);
    	//line fsm
        TakeFiveFSM.linedata = linedata;
        TakeFiveFSM.bumpdata = bumpdata;
        TakeFiveFSM.speeddata = speed;
        // use bump and line sensors to determine next input
        TakeFiveFSM.CurrentState = NextStateFunction(&TakeFiveFSM);

        // produce output based on current state
        OutputFunction(&TakeFiveFSM);
    }
}
