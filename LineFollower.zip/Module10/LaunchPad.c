// built-in LED1 connected to P1.0
// negative logic built-in Button 1 connected to P1.1
// negative logic built-in Button 2 connected to P1.4
// built-in red LED connected to P2.0
// built-in green LED connected to P2.1
// built-in blue LED connected to P2.2

#include "driverlib.h"
#include "gpio.h"
#include "LaunchPad.h"

//------------LaunchPad_Init------------
// Initialize Switch input and LED output
// Input: none
// Output: none
void LaunchPad_Init(void){
  // setup bump switches as input with pull up resistor

  // set the red led 1.0 as ouptut and set it low

  // set RGB pins as output with high drive strength and set them all low
  // pins are 2.0-2.2
  GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1,GPIO_PIN1);
  GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1,GPIO_PIN4);

  GPIO_setAsOutputPin(GPIO_PORT_P1,GPIO_PIN0);
  GPIO_setOutputLowOnPin(GPIO_PORT_P1,GPIO_PIN0);

  GPIO_setAsOutputPin(GPIO_PORT_P2,GPIO_PIN0);
  GPIO_setDriveStrengthHigh(GPIO_PORT_P2,GPIO_PIN0);
  GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN0);

  GPIO_setAsOutputPin(GPIO_PORT_P2,GPIO_PIN1);
  GPIO_setDriveStrengthHigh(GPIO_PORT_P2,GPIO_PIN1);
  GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN1);

  GPIO_setAsOutputPin(GPIO_PORT_P2,GPIO_PIN2);
  GPIO_setDriveStrengthHigh(GPIO_PORT_P2,GPIO_PIN2);
  GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN2);
}


//------------LaunchPad_Input------------
// Input from Switches
// Input: none
// Output: 0x00 none
//         0x01 Button1
//         0x02 Button2
//         0x03 both Button1 and Button2
uint8_t LaunchPad_Input(void){
  // read pin P1.1 [000000X0] and pin P1.4 [000X0000]
  // use bit-shifting to return appropriate output
  //GPIO_PORT_P1 = GPIO_PIN_P1 <<1; //gpio get pin
  //uint8_t var1 = GPIO_PIN1 <<1;
  uint8_t var1 = GPIO_getInputPinValue(GPIO_PORT_P1,GPIO_PIN1) ;
  var1= ~var1 & 0x1;

  uint8_t var2 = GPIO_getInputPinValue(GPIO_PORT_P1,GPIO_PIN4);
  var2 =~var2 &0x1;
  var2 = var2 <<1;
  uint8_t var3 = var1|var2;
  //var3 = ~var3;
  //var3 = var3 & 0x03;
  return var3;
}

//------------LaunchPad_LED------------
// Output to LaunchPad red LED
// Input: 0 off, 1 on
// Output: none
void LaunchPad_LED(uint8_t data){
  // set P1.0 as either high or low, according to
  // the value in data
    if(data == 0b00000000){
        GPIO_setOutputLowOnPin(GPIO_PORT_P1,GPIO_PIN0);
    }else{
        GPIO_setOutputHighOnPin(GPIO_PORT_P1,GPIO_PIN0);
    }

}

//------------LaunchPad_Output------------
// Output to LaunchPad LEDs
// Input: 0 off, bit0=red,bit1=green,bit2=blue
// Output: none
void LaunchPad_Output(uint8_t data){
  // write three bits (data) to the appropriate
  // pins (0,1,2) on port 2
  //uint8_t var1 = data & 0b00000001;
  //uint8_t var2 = data & 0b00000010;
  //uint8_t var3 = data & 0b00000100;
  if(data == 0x1){ //red
     GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN0);
  }else{
     GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN0);
  }
  if(data == 0x2){ //green
     GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN1);
  }else{
     GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN1);
  }
  if(data == 0x3){ //blue
     GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN2);
  }else{
     GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN2);
  }
  //GPIO_setOutputHighOnPin(GPIO_PORT_P2,data);
  //GPIO_setOutputLowOnPin(GPIO_PORT_P2,~data);
}
