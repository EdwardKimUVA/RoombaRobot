#include <stdint.h>
/*
 * Reflectance.c
 * Provides functions to
 * 1. Initialize Pololu reflectance sensor
 * 2. Read Pololu reflectance sensor
 * 3. Determine robot position
 * 4. Determine robot status
 *
 */

//#include <../driverlib/driverlib.h>

#include "Clock.h"
#include "Reflectance.h"
#include "gpio.h"
#define ALLBITS  0xFF
#define BITSHIFT 0x01

//------------Reflectance_Init------------
// Initialize sensor array to GPIO, set LEDs (P5.3 and P9.2)
// as output and sensors (P7.0-P7.7) as output
// Input: none
// Output: none
void Reflectance_Init(void){
      GPIO_setAsOutputPin(GPIO_PORT_P5,GPIO_PIN3);
      GPIO_setAsOutputPin(GPIO_PORT_P9,GPIO_PIN2); //set leds as ouput

      GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN0);
      GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN1);
      GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN2);
      GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN3);
      GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN4);
      GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN5);
      GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN6);
      GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN7); //sensors are output
}

uint8_t Reflectance_Read(uint32_t time){
    // 1. Turn on even and odd LEDs
    // 2. Charge reflectance sensor capacitors (set as output and high on P7.0-P7.7)
    // 3. Wait 10us for capacitors to charge
    // 4. Set reflectance sensor (P7.0-P7.7) as input
    // 5. Wait @param time
    // 6. Read reflectance sensor values and assign to result
    // 8. Turn off even and odd LEDs
    GPIO_setOutputHighOnPin(GPIO_PORT_P5,GPIO_PIN3); //even and odd LEDs on
    GPIO_setOutputHighOnPin(GPIO_PORT_P9,GPIO_PIN2);

    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN0);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN1);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN2);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN3);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN4);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN5);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN6);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN7); //sensor output
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN0);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN1);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN2);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN3);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN4);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN5);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN6);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN7); //sensor high output
    Clock_Delay1us(10); //delay
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN0);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN1);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN2);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN3);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN4);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN5);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN6);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN7); //sensors are now input
    Clock_Delay1us(time); //delay by var amount
    uint8_t var0 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN0); //bitshifting to get sensor values for each bit
    var0 = var0;
    uint8_t var1 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN1);
    var1 = var1 <<1;
    uint8_t var2 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN2);
    var2 = var2 <<2;
    uint8_t var3 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN3);
    var3 = var3 <<3;
    uint8_t var4 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN4);
    var4 = var4 <<4;
    uint8_t var5 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN5);
    var5 = var5 <<5;
    uint8_t var6 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN6);
    var6 = var6 <<6;
    uint8_t var7 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN7);
    var7 = var7 <<7;
    uint8_t result = var7 | var6 | var5 | var4 | var3 | var2 | var1 | var0; //combine
    GPIO_setOutputLowOnPin(GPIO_PORT_P5,GPIO_PIN3);
    GPIO_setOutputLowOnPin(GPIO_PORT_P9,GPIO_PIN2); //led low output
    return result; //current sensor values
}
//------------Reflectance_Read------------
// Read reflectance sensor
// Input: the delay time in us
// Output: result the sensor readings, bit 0 corresponds
//         to the rightmost sensor, bit 7 to the leftmost sensor
void Reflectance_Start(){
    // 1. Turn on even and odd LEDs
    // 2. Charge reflectance sensor capacitors (set as output and high on P7.0-P7.7)
    // 3. Wait 10us for capacitors to charge
    // 4. Set reflectance sensor (P7.0-P7.7) as input
    // 5. Wait @param time
    // 6. Read reflectance sensor values and assign to result
    // 8. Turn off even and odd LEDs
    GPIO_setOutputHighOnPin(GPIO_PORT_P5,GPIO_PIN3); //even and odd LEDs on
    GPIO_setOutputHighOnPin(GPIO_PORT_P9,GPIO_PIN2);

    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN0);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN1);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN2);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN3);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN4);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN5);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN6);
    GPIO_setAsOutputPin(GPIO_PORT_P7,GPIO_PIN7); //sensor output
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN0);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN1);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN2);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN3);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN4);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN5);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN6);
    GPIO_setOutputHighOnPin(GPIO_PORT_P7, GPIO_PIN7); //sensor high output
    Clock_Delay1us(10); //delay
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN0);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN1);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN2);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN3);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN4);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN5);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN6);
    GPIO_setAsInputPin(GPIO_PORT_P7,GPIO_PIN7); //sensors are now input
}
    //split start and end
uint8_t Reflectance_End(){
    //Clock_Delay1us(time); //delay by var amount
    uint8_t var0 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN0); //bitshifting to get sensor values for each bit
    var0 = var0;
    uint8_t var1 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN1);
    var1 = var1 <<1;
    uint8_t var2 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN2);
    var2 = var2 <<2;
    uint8_t var3 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN3);
    var3 = var3 <<3;
    uint8_t var4 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN4);
    var4 = var4 <<4;
    uint8_t var5 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN5);
    var5 = var5 <<5;
    uint8_t var6 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN6);
    var6 = var6 <<6;
    uint8_t var7 = GPIO_getInputPinValue(GPIO_PORT_P7,GPIO_PIN7);
    var7 = var7 <<7;
    uint8_t result = var7 | var6 | var5 | var4 | var3 | var2 | var1 | var0; //combine
    GPIO_setOutputLowOnPin(GPIO_PORT_P5,GPIO_PIN3);
    GPIO_setOutputLowOnPin(GPIO_PORT_P9,GPIO_PIN2); //led low output
    return result; //current sensor values
}

//------------Reflectance_Center------------
// Determine robot's status over the line
// Input: the delay time in us
// Output: result the robot location status (LOST/RIGHT/LEFT/ON LINE)
uint8_t Reflectance_Center(uint32_t time){
    //Get reflectance read data
    //Get value from left center sensor
    //Get value from right center sensor

    /* Check robot status truth table
     * INPUT (L,R) | OUTPUT
     * ------------|------------
     *      11     | ON_LINE (3)
     *      10     | LEFT    (2)
     *      01     | RIGHT   (1)
     *      00     | LOST    (0)
     */
    uint8_t answer = Reflectance_End(); //get data value for sensor values
    uint8_t var1 = answer >>3 & 0x1;
    uint8_t var2 = answer >>4 & 0x1;
    var2 = var2<<1; // left bit is sensor 4 right bit is sensor 3
    uint8_t answer2 = var1 | var2;
    //if(answer2)
    return answer2;
}

//------------Reflectance_Position------------
// Determine robot's status over the line
// Input: the collected sensor data
// Output: the position value between +345 (most left)
//         to -345 (most right)
int32_t Reflectance_Position(uint8_t data){
    int32_t W_i[] = {334, 238, 142, 48, -48, -142, -238, -334}; //weights from 7 to 0
    int32_t sum =0;
    int32_t count =0;
    int32_t lostcount =0;
    if(((data >>0) & 0x1) == 1){
        sum += W_i[7];
        count++;
    }else{
        lostcount++;
    }
    if(((data >>1) & 0x1) == 1){
        sum += W_i[6];
        count++;
    }
    else{
            lostcount++;
        }
    if(((data >>2) & 0x1) == 1){
        sum += W_i[5];
        count++;
    }
    else{
            lostcount++;
        }
    if(((data >>3) & 0x1) == 1){
        sum += W_i[4];
        count++;
    }
    else{
            lostcount++;
        }
    if(((data >>4) & 0x1) == 1){
        sum += W_i[3];
        count++;
    }
    else{
            lostcount++;
        }
    if(((data >>5) & 0x1) == 1){
        sum += W_i[2];
        count++;
    }
    else{
            lostcount++;
        }
    if(((data >>6) & 0x1) == 1){
        sum += W_i[1];
        count++;
    }
    else{
            lostcount++;
        }
    if(((data >>7) & 0x1) == 1){
        sum += W_i[0];
        count++;
    }
    else{
            lostcount++;
        }
    if(count == 0){
        count =1;
    }
    if(lostcount == 8){
        return -900;
    }
    return sum/count; //sum of weights divided by the number of 1s in data
}

