#include "FSM.h"
#include "Clock.h"
#include "gpio.h"
#include "Reflectance.h"
#include "PWM.h"
#include "Motor.h"
#include "Nokia5110.h"
#define CYCLING_DELAY_MS     100
#define HEARTBEAT_DELAY_MS   100
#define DEBOUNCING_DELAY_MS  100

//--------------------------------------------------------------------------
// Initialize FSM
//--------------------------------------------------------------------------
void InitializeFSM(FSMLine *FSM)
{
    FSM->CurrentState = RobotCentered;
}

//--------------------------------------------------------------------------
// Determine next FSM state
//--------------------------------------------------------------------------
FSMLineState NextStateFunction(FSMLine *FSM)
{
    FSMLineState NextState = FSM->CurrentState;

    int position = Reflectance_Position(FSM->linedata); // if (pos > 200

    switch (FSM->CurrentState){
//--Heart Beating states----------------------------------------------------
    case RobotCentered:
        if(FSM->bumpdata !=0x00 && FSM->speeddata !=0){ //0x01 0x10
            NextState = bumped;
        }
        else if(position > 120 && FSM->speeddata !=0){
            NextState = RobotTooLeft;
        }
        else if(position < -120 && position != -900 && FSM->speeddata !=0) {
            NextState = RobotTooRight;
        }
        else if(position < 120 && position >-120 && FSM->speeddata !=0) {
            NextState = RobotCentered;
        }
        else if(position == -900){
            NextState = Lost;
        }else if(FSM->speeddata == 0){
        	NextState = tempStop;
        }
        break;
    case RobotTooLeft:
    	 if(FSM->bumpdata !=0x00 && FSM->speeddata !=0){ //0x01 0x10
    	     NextState = bumped;
    	 }
    	 else if(position > 120 && FSM->speeddata !=0){
    	     NextState = RobotTooLC;
    	 }
    	 else if(position < -120 && position != -900 && FSM->speeddata !=0) {
    	     NextState = RobotTooRight;
    	 }
    	 else if(position < 120 && position > -120 && FSM->speeddata !=0) {
    		 NextState = RobotCentered;
    	 }
    	 else if(position == -900){
    	     NextState = Lost;
         }else if(FSM->speeddata == 0){
         	NextState = tempStop;
         }

    	 break;
    case RobotTooLC:
        	 if(FSM->bumpdata !=0x00 && FSM->speeddata !=0){ //0x01 0x10
        	     NextState = bumped;
        	 }
        	 else if(position > 120 && FSM->speeddata !=0){
        	     NextState = RobotTooLeft;
        	 }
        	 else if(position < -120 && position != -900 && FSM->speeddata !=0) {
        	     NextState = RobotTooRight;
        	 }
        	 else if(position < 120 && position >-120 && FSM->speeddata !=0) {
        		 NextState = RobotCentered;
        	 }
        	 else if(position == -900){
        	     NextState = Lost;
             }else if(FSM->speeddata == 0){
             	NextState = tempStop;
             }

        	 break;
    /*case HardLeft:
        	 if(FSM->bumpdata !=0x00){ //0x01 0x10
        	     NextState = bumped;
        	 }
        	 else if(position > 42){
        	     NextState = RobotTooLeft;
        	 }
        	 else if(position < -42 && position != -900) {
        	     NextState = RobotTooRight;
        	 }
        	 else if(position >-42 && position <42) {
        		 NextState = RobotCentered;
        	 }
        	 else if(position == -900){
        	     NextState = HardLeft;
        	 }
        	 break;*/
//--Heart Beat paused states------------------------------------------------
    case RobotTooRight:
    	 if(FSM->bumpdata !=0x00 && FSM->speeddata !=0){ //0x01 0x10
    	            NextState = bumped;
    	        }
    	        else if(position > 120 && FSM->speeddata !=0){
    	            NextState = RobotTooLeft;
    	        }
    	        else if(position < -120 && position != -900 && FSM->speeddata !=0) {
    	            NextState = RobotTooRC;
    	        }
    	        else if(position > -120 && position <120 && FSM->speeddata !=0) {
    	            NextState = RobotCentered;
    	        }
    	        else if(position == -900){
    	            NextState = Lost;
    	        }else if(FSM->speeddata == 0){
    	        	NextState = tempStop;
    	        }
    	        break;
    case RobotTooRC:
        	 if(FSM->bumpdata !=0x00 && FSM->speeddata !=0){ //0x01 0x10
        	     NextState = bumped;
        	 }
        	 else if(position > 120 && FSM->speeddata !=0){
        	     NextState = RobotTooLeft;
        	 }
        	 else if(position < -120 && position != -900 && FSM->speeddata !=0) {
        	     NextState = RobotTooRight;
        	 }
        	 else if(position <120 && position >-120 && FSM->speeddata !=0) {
        		 NextState = RobotCentered;
        	 }
        	 else if(position == -900){
        	     NextState = Lost;
 	        }else if(FSM->speeddata == 0){
 	        	NextState = tempStop;
 	        }
        	 break;
    /*case HardRight:
        	 if(FSM->bumpdata !=0x00){ //0x01 0x10
        	     NextState = bumped;
        	 }
        	 else if(position > 0){
        	     NextState = RobotTooLeft;
        	 }
        	 else if(position < 0 && position != -900) {
        	     NextState = RobotTooRight;
        	 }
        	 else if(position == 0) {
        		 NextState = RobotCentered;
        	 }
        	 else if(position == -900){
        	     NextState = Lost;
        	 }
        	 break;*/
    case Lost:
   	 if(FSM->bumpdata !=0x00){ //0x01 0x10
   	     NextState = bumped;
   	 }
   	 else if(position > 42){
   	     NextState = Lost;
   	 }
   	 else if(position < -42 && position != -900) {
   	     NextState = Lost;
   	 }
   	 else if(position == 0) {
   		 NextState = Lost;
   	 }
   	 else if(position == -900){
   	     NextState = Lost;
   	 }
   	 break;
    case bumped:
        //Ensures S2 has precedence
        if(FSM->bumpdata !=0x00 && FSM->speeddata !=0){ //0x01 0x10
            NextState = bumped;
        }
        else if(position > 120 && FSM->speeddata !=0){
            NextState = RobotTooLeft;
        }
        else if(position < -120 && position != -900 && FSM->speeddata !=0) {
            NextState = RobotTooRight;
        }
        else if(position < 120 && position >-120 && FSM->speeddata !=0) {
            NextState = RobotCentered;
        }
        else if(position == -900){
            NextState = Lost;
        }else if(FSM->speeddata == 0){
        	NextState = tempStop;
        }
        break;
    case tempStop:
        if(FSM->bumpdata !=0x00 && FSM->speeddata !=0){ //0x01 0x10
            NextState = bumped;
        }
        else if(position > 120 && FSM->speeddata !=0){
            NextState = RobotTooLeft;
        }
        else if(position < -120 && position != -900 && FSM->speeddata !=0) {
            NextState = RobotTooRight;
        }
        else if(position < 120 && position >-120 && FSM->speeddata !=0) {
            NextState = RobotCentered;
        }
        else if(position == -900){
            NextState = Lost;
        }else if(FSM->speeddata == 0){
        	NextState = tempStop;
        }
        break;
    }
    return NextState;
}
//--------------------------------------------------------------------------
// Determine LED output based on state
//--------------------------------------------------------------------------
void OutputFunction(FSMLine *FSM)
{
    switch (FSM->CurrentState) {
    case RobotCentered:
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN5); //Front Bumper lights on
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN0);

        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN7); //back off
        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN6);
        Motor_Forward(FSM->speeddata,FSM->speeddata);
        Nokia5110_Clear();
        Nokia5110_SetCursor(0, 1);
        Nokia5110_OutString("RobotCentered");
        //Nokia5110_SetCursor(0, 2);
        Nokia5110_OutUDec(FSM->speeddata);
        Clock_Delay1us(500);
        break;
    case RobotTooLeft:
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN5); //Front Bumper lights on //right

        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN0); //left
        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN7); //back off //right
        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN6); //left
        Motor_Left(FSM->speeddata,FSM->speeddata);
        Nokia5110_Clear();
        Nokia5110_SetCursor(0, 1);
        Nokia5110_OutString("RobotTooLeft");
        //Nokia5110_SetCursor(0, 2);
        Nokia5110_OutUDec(FSM->speeddata);
        Clock_Delay1us(500);
        break;
    case RobotTooLC:
    	GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN5); //Front Bumper lights on
    	GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN0);

    	GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN7); //back off
    	GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN6);
    	Motor_Forward(FSM->speeddata,FSM->speeddata);
        Nokia5110_Clear();
        Nokia5110_SetCursor(0, 1);
        Nokia5110_OutString("RobotTooLC");
        //Nokia5110_SetCursor(0, 2);
        Nokia5110_OutUDec(FSM->speeddata);
    	Clock_Delay1us(500);
    	break;
    /*case HardLeft:
    	GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN5); //Front Bumper lights on //right

    	GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN0); //left
    	GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN7); //back off //right
    	GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN6); //left
    	Motor_Right(75,25);
    	break;*/
    case RobotTooRight:
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN0); //Front Bumper lights on //left

        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN5); //RIGHT
        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN7); //back off //right
        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN6); //left
        Motor_Right(FSM->speeddata,FSM->speeddata);
        Nokia5110_Clear();
        Nokia5110_SetCursor(0, 1);
        Nokia5110_OutString("RobotTooRight");
        //Nokia5110_SetCursor(0, 2);
        Nokia5110_OutUDec(FSM->speeddata);
        Clock_Delay1us(500);
        break;
    case RobotTooRC:
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN5); //Front Bumper lights on
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN0);

        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN7); //back off
        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN6);
        Motor_Forward(FSM->speeddata,FSM->speeddata);
        Nokia5110_Clear();
        Nokia5110_SetCursor(0, 1);
        Nokia5110_OutString("RobotTooRC");
        //Nokia5110_SetCursor(0, 2);
        Nokia5110_OutUDec(FSM->speeddata);
        Clock_Delay1us(500);
        break;
   /*case HardRight:
       GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN5); //Front Bumper lights on //right

       GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN0); //left
       GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN7); //back off //right
       GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN6); //left
       Motor_Right(25,75);
       break;*/
    case Lost:
        // Do nothing (release happens too quickly to see behavior change)
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN6); //Back bumper lights on
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN7);
        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN0); //left
        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN5); //RIGHT
        Nokia5110_Clear();
        Nokia5110_SetCursor(0, 1);
        Nokia5110_OutString("Lost");
        //Nokia5110_SetCursor(0, 2);
        Nokia5110_OutUDec(FSM->speeddata);
        Motor_Stop();
        break;
    case bumped:
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN5); //Front Bumper lights on
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN0);
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN6); //Back bumper lights on
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN7);
        Nokia5110_Clear();
        Nokia5110_SetCursor(0, 1);
        Nokia5110_OutString("bumped");
        //Nokia5110_SetCursor(0, 2);
        Nokia5110_OutUDec(FSM->speeddata);
        Motor_Stop();
        break;
    case tempStop:
           GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN5); //Front Bumper lights on
           GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN0);
           //GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN6); //Back bumper lights on
           GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN7);
           Nokia5110_Clear();
           Nokia5110_SetCursor(0, 1);
           Nokia5110_OutString("tempStop");
           //Nokia5110_SetCursor(0, 2);
           Nokia5110_OutUDec(FSM->speeddata);
           Motor_Stop();
           break;
    }

}
