#ifndef FSM_H_
#define FSM_H_

#include "PortPins.h"
#include "Switch.h"

// Type Definitions
typedef enum {
    RobotCentered,
    RobotTooLeft,
	RobotTooLC,
    RobotTooRight,
	RobotTooRC,
    Lost,
    bumped,
	tempStop
} FSMLineState;
typedef enum {
	Normal_Operation,
	Take_It_Slow,
	Stop
} FSMBoostState;
typedef struct {
    FSMLineState     CurrentState;      // Current state of the FSM
    uint8_t linedata;    // Current input of the FSM S1
    uint8_t bumpdata;   // Current input of the FSM S2
    uint16_t speeddata; //speed based on luxdata and acceldata
} FSMLine;
typedef struct {
    FSMBoostState     CurrentState;      // Current state of the FSM
    uint8_t luxdata;	//luxdata is used as a check to determine the speed, can be values of 0 = dark, 1 = dim, 2 = bright
    uint8_t acceldata;  //checks to see if the bot is being picked up
} FSMBooster;
// Function Prototypes
void InitializeFSM(FSMLine *FSM);
FSMLineState NextStateFunction(FSMLine *FSM);
void OutputFunction(FSMLine *FSM);
// Function Prototypes
void InitializeFSM2(FSMBooster *FSM);
FSMBoostState NextStateFunction2(FSMBooster *FSM);
uint16_t OutputFunction2(FSMBooster *FSM);

#endif /* FSM_H_ */
