// Write me!
#include "PWM.h"
#include "driverlib.h"
Timer_A_PWMConfig PWM_Config_Right =
{
    TIMER_A_CLOCKSOURCE_SMCLK,       // timer sources from SMCLK
    TIMER_A_CLOCKSOURCE_DIVIDER_1,     // SMCLK / 1 = 12 MHz
    1,                                   //timerPeriod
    TIMER_A_CAPTURECOMPARE_REGISTER_3, // P2.6 PWM is mapped to TA0 CCR4
    TIMER_A_OUTPUTMODE_RESET_SET,      // Reset set mode allows for PWM output
    0                                   // dutyCycle
};
Timer_A_PWMConfig PWM_Config_Left =
{
    TIMER_A_CLOCKSOURCE_SMCLK,       // timer sources from SMCLK
    TIMER_A_CLOCKSOURCE_DIVIDER_1,     // SMCLK / 1 = 12 MHz
    1,                                   //timerPeriod
    TIMER_A_CAPTURECOMPARE_REGISTER_4, // P2.7 PWM is mapped to TA0 CCR4
    TIMER_A_OUTPUTMODE_RESET_SET,      // Reset set mode allows for PWM output
    0                                   // dutyCycle
};
void PWM_Init(uint16_t period, uint16_t duty3, uint16_t duty4){
    GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P2,GPIO_PIN7 | GPIO_PIN6, GPIO_PRIMARY_MODULE_FUNCTION);
    PWM_Config_Left.timerPeriod = period;
    PWM_Config_Right.timerPeriod = period;
    PWM_Duty_Right(duty3);
    PWM_Duty_Right(duty4);
    Timer_A_generatePWM(TIMER_A0_BASE,&PWM_Config_Left);
    Timer_A_generatePWM(TIMER_A0_BASE,&PWM_Config_Right);
}
uint16_t convert(uint16_t var){
    return var*PWM_Config_Left.timerPeriod/100;
}
void PWM_Duty_Right(uint16_t duty1){
    PWM_Config_Right.dutyCycle = convert(duty1);
    Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_3 , convert(duty1));
}
void PWM_Duty_Left(uint16_t duty4){
    PWM_Config_Left.dutyCycle = convert(duty4);
    Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_4 , convert(duty4));
}
